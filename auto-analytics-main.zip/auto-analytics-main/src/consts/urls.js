// all components get api server base url from this file
// Local API server url
// export const BASE_URL =  'http://127.0.0.1:8000'
// Hosted API server url
export const BASE_URL = "https://autoapi-production.up.railway.app";

//default csv file link for sales forecast page
export const demoCSVFileURL =
  "https://raw.githubusercontent.com/aj-2000/autoapi/main/App/datasets/demo_sales_dataset.csv";
// 2nd file
// export const demoCSVFileURL =
//   "https://raw.githubusercontent.com/aj-2000/autoapi/main/App/datasets/total_car_sales.csv"
